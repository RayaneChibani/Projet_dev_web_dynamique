<section class="py-5">
    <div class="container">
        <h2 class="text-center mb-5 fw-semibold">Notre Équipe</h2>
        <div class="row justify-content-center">

            <div class="col-md-4 col-lg-3 mb-4">
                <div class="card text-center h-100 shadow-sm">
                    <img src="https://via.placeholder.com/150" class="card-img-top rounded-circle mx-auto mt-4" alt="Avatar développeur" style="width: 120px; height: 120px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title">Schellenbaum Mathieu</h5>
                        <p class="card-text text-muted">Développeur Frontend</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-lg-3 mb-4">
                <div class="card text-center h-100 shadow-sm">
                    <img src="https://via.placeholder.com/150" class="card-img-top rounded-circle mx-auto mt-4" alt="Avatar développeur" style="width: 120px; height: 120px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title">Xayphrarath Sylvain</h5>
                        <p class="card-text text-muted">Développeur Frontend</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-lg-3 mb-4">
                <div class="card text-center h-100 shadow-sm">
                    <img src="https://via.placeholder.com/150" class="card-img-top rounded-circle mx-auto mt-4" alt="Avatar développeur" style="width: 120px; height: 120px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title">Rayane</h5>
                        <p class="card-text text-muted">Chef de projet et développeur backend</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-lg-3 mb-4">
                <div class="card text-center h-100 shadow-sm">
                    <img src="https://via.placeholder.com/150" class="card-img-top rounded-circle mx-auto mt-4" alt="Avatar développeur" style="width: 120px; height: 120px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title">Alioune</h5>
                        <p class="card-text text-muted">Développeur backend</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<?php /**PATH C:\laragon\www\bookShekf\resources\views/public/partials/equipe.blade.php ENDPATH**/ ?>