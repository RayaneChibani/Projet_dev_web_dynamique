<section class="py-5 bg-light text-center">
    <div class="container">
        <h2 class="mb-4 fw-semibold">Pourquoi BookShelf ?</h2>
        <p class="lead mx-auto" style="max-width: 700px;">
            BookShelf vous aide à garder une trace de vos lectures.
            Organisez vos livres par genre, suivez votre progression
            et notez ceux que vous avez lus.
        </p>
    </div>
</section>
<?php /**PATH C:\laragon\www\bookShekf\resources\views/public/partials/presentation.blade.php ENDPATH**/ ?>