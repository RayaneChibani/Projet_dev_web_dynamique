<section class="bg-primary text-white text-center py-5">
    <div class="container">
        <h1 class="display-4 fw-bold">Organisez votre lecture avec BookShelf</h1>
        <p class="lead mt-3">Ajoutez, suivez et notez vos lectures. Votre bibliothèque, à portée de clic.</p>
        <div class="mt-4">
    
        </div>
    </div>
</section>
<?php /**PATH C:\laragon\www\bookShekf\resources\views/public/partials/hero.blade.php ENDPATH**/ ?>