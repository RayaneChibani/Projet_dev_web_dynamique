<footer class="text-center text-muted py-4 mt-5 border-top">
    <div class="container">
        <p class="mb-2">© <?php echo e(date('Y')); ?> BookShelf. Tous droits réservés.</p>
        <ul class="list-inline">
            <li class="list-inline-item">
                <a href="#" class="text-muted text-decoration-none">Mentions légales</a>
            </li>
            <li class="list-inline-item">
                <a href="#" class="text-muted text-decoration-none">Conditions d'utilisation</a>
            </li>
            <li class="list-inline-item">
                <a href="#" class="text-muted text-decoration-none">Contact</a>
            </li>
        </ul>
    </div>
</footer>
<?php /**PATH C:\laragon\www\bookShekf\resources\views/public/partials/footer.blade.php ENDPATH**/ ?>