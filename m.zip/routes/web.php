<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PublicController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/home', [PublicController::class, 'home'])->name('home');

// Affichage de la page À propos
Route::get('/a-propos', function () {
    return view('about');
})->name('about');

// Affichage de la page Contact
Route::get('/contact', function () {
    return view('contact');
})->name('contact');

// (optionnel) Route POST pour formulaire de contact
Route::post('/contact', [App\Http\Controllers\ContactController::class, 'send'])->name('contact.send');