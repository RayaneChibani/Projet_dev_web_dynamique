@extends('layouts.app')

@section('content')
    @include('public.partials.hero')
    @include('public.partials.presentation')
    @include('public.partials.equipe')
    @include('public.partials.features')
    @include('public.partials.footer')
@endsection
