<section class="py-5 bg-light">
    <div class="container">
        <h2 class="text-center mb-5 fw-semibold">Fonctionnalités clés</h2>
        <div class="row text-center">

            <div class="col-md-3 mb-4">
                <i class="fas fa-book fa-3x text-primary mb-3"></i>
                <h5>Gestion de livres personnalisée</h5>
            </div>

            <div class="col-md-3 mb-4">
                <i class="fas fa-chart-line fa-3x text-success mb-3"></i>
                <h5>Suivi de l'état de lecture</h5>
            </div>

            <div class="col-md-3 mb-4">
                <i class="fas fa-layer-group fa-3x text-warning mb-3"></i>
                <h5>Classement par genre</h5>
            </div>

            <div class="col-md-3 mb-4">
                <i class="fas fa-star-half-alt fa-3x text-danger mb-3"></i>
                <h5>Évaluation et commentaires</h5>
            </div>

        </div>
    </div>
</section>
