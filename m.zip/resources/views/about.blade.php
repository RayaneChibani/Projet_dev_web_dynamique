
@extends('layouts.app')

@section('title', 'À propos')

@section('content')
<div class="container mt-5">
    <h1 class="mb-4">À propos du projet</h1>

    <p>
        Ce projet a été conçu pour répondre à un besoin clair : offrir aux utilisateurs une plateforme intuitive, efficace et accessible, leur permettant de gérer leur bibliothèque personnelle.
    </p>

    <h3 class="mt-4">Objectif du projet</h3>
    <p>
        L’objectif est de simplifier la gestion de la lecture personnelle grâce à une interface conviviale, des fonctionnalités organisées, et une expérience fluide.
    </p>

    <h3 class="mt-4">Utilité pour les utilisateurs</h3>
    <ul>
        <li>Ajout et organisation de livres personnels par genre.</li>
        <li>Suivi de l’état de lecture (à lire, en cours, terminé).</li>
        <li>Notation et ajout de commentaires sur les livres.</li>
    </ul>

    <h3 class="mt-4">Points forts</h3>
    <ul>
        <li>Technologies modernes (Laravel 10+, Bootstrap 5, FontAwesome).</li>
        <li>Design responsive, expérience fluide.</li>
        <li>Interface publique claire, intuitive et informative.</li>
    </ul>
</div>
@endsection
