<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Genre;
use App\Models\User;    // ← pour GenreSeeder
use App\Models\Book;   

class BookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $genres = Genre::all();

        if ($genres->count() === 0) {
            $this->command->warn('Aucun genre trouvé. Livres non créés.');
            return;
        }

        $genres->each(function ($genre) {
            Book::factory(5)->create([
                'genre_id' => $genre->id,
                'user_id' => $genre->user_id,
            ]);
        });
    
    }
}
