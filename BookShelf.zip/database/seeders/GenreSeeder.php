<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;    // ← pour GenreSeeder
use App\Models\Genre;   // ← pour BookSeeder aussi
use App\Models\Book;    

class GenreSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = User::all();

        if ($users->count() === 0) {
            $this->command->warn('Aucun utilisateur trouvé. Genres non créés.');
            return;
        }

        $users->each(function ($user) {
            Genre::factory(3)->create([
                'user_id' => $user->id,
            ]);
        });
    }
    
}
