<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\User;    // ← pour GenreSeeder
use App\Models\Genre;   // ← pour BookSeeder aussi
use App\Models\Book;   

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Book>
 */
class BookFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'title' => fake()->sentence(3),
            'author' => fake()->name(),
            'status' => fake()->randomElement(['to_read', 'reading', 'finished']),
            'rating' => fake()->optional()->numberBetween(1, 5),
            'review' => fake()->optional()->paragraph(),
            'user_id' => User::factory(), // sera remplacé dans le seeder
            'genre_id' => Genre::factory(), // idem
        ];
    }
}
